package com;

import java.util.Scanner;
import java.util.Vector;

public class Currency {
	static int deno[] = { 1, 2, 5, 10, 20, 50, 100, 500, 1000, 2000 };
	static int n = deno.length;

	static void findMin(int V) {

		Vector<Integer> ans = new Vector<>();

		for (int i = n - 1; i >= 0; i--) {

			while (V >= deno[i]) {
				V -= deno[i];
				ans.add(deno[i]);
			}
		}

		for (int i = 0; i < ans.size(); i++) {
			System.out.println(" " + ans.elementAt(i));
		}
	}

	public static void main(String[] args) {
		while (true) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the Currency: ");
			int n = sc.nextInt();
			System.out.println("Brake-Down is: " + n + ": ");
			findMin(n);

		}

	}

}
