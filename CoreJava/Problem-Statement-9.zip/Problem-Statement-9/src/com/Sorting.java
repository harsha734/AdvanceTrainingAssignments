package com;

import java.util.HashMap;
import java.util.Scanner;

public class Sorting {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("enter length of array : ");
		int[] arr = new int[sc.nextInt()];
		System.out.println("enter array values : ");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();

		}
		HashMap<Integer, Integer> hm = solveIterative(arr);

		for (int value : hm.keySet()) {
			System.out.println(value + " occurs " + hm.get(value) + " times");
		}
		sc.close();
	}

	public static HashMap<Integer, Integer> solveIterative(int[] arr) {
		HashMap<Integer, Integer> hm = new HashMap<>();
		for (int value : arr) {
			if (!hm.containsKey(value)) {
				hm.put(value, 1);
			} else {
				hm.put(value, hm.get(value) + 1);
			}
		}
		return hm;
	}

}
