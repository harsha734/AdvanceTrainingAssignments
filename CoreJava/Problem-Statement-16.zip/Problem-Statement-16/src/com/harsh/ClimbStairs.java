package com.harsh;

import java.util.Scanner;

public class ClimbStairs {
	// A simple recursive program to find
    // n'th fibonacci number
    static int fibonacci(int a)
    {
        if (a <= 1)
            return a;
        return fibonacci(a - 1) + fibonacci(a - 2);
    }
 
    // Returns number of ways to reach s'th stair
    static int countWays(int num)
    {
        return fibonacci(num + 1);
    }
 
    /* Driver program to test above function */
    public static void main(String args[])
    {
        Scanner num=new Scanner(System.in);
        System.out.println("Enter a Number :");
      int  nth_number=num.nextInt();
//       int num1=3;
        System.out.println("Number of ways = " + countWays(nth_number));
   num.close(); }
}
