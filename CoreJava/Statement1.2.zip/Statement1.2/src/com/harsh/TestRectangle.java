package com.harsh;



public class TestRectangle {

	 public static void main(String args[]) {
	        Rectangle object1 = new Rectangle();
	        object1.input();
	        object1.calculate();
	        object1.display();
	        Rectangle object2 = new Rectangle();
	        object2.input();
	        object2.calculate();
	        object2.display();
	        Rectangle object3 = new Rectangle();
	        object3.input();
	        object3.calculate();
	        object3.display();
	        Rectangle object4 = new Rectangle();
	        object4.input();
	        object1.calculate();
	        object4.display();
	        Rectangle object5 = new Rectangle();
	        object5.input();
	        object5.calculate();
	        object5.display();
	    }
}
