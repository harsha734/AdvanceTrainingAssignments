package com;

import java.util.HashSet;
import java.util.Scanner;

public class RepeatingElement {
	public static void main(String[] args) {
		//int[] a= {1, 2, 3, 10, 2, 4, 5, 7, 8 };
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter length of array : ");
		int[] arr = new int[sc.nextInt()];
		System.out.println("Enter array values : ");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();

		}
		int temp=-1;
		HashSet<Integer>hs=new HashSet<>();
		for(int i=arr.length-1; i>=0;i--)
		{
			if(hs.contains(arr[i])) {
				temp=i;
			}
			else
			{
				hs.add(arr[i]);
			}
		}
		if(temp!=-1) {
			System.out.println("first repeated element is "+arr[temp]);
		}
		else {
			System.out.println("first repeated element not found");
		}
		sc.close();
	}
}
