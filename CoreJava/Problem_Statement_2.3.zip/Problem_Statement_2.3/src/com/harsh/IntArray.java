package com.harsh;

import java.util.Arrays;

public class IntArray {
	public static int[] insertX(int n, int arr[], int x, int pos) {
		int i;


		int newarr[] = new int[n + 1];

		for (i = 0; i < n + 1; i++) {
			if (i < pos - 1)
				newarr[i] = arr[i];
			else if (i == pos - 1)
				newarr[i] = x;
			else
				newarr[i] = arr[i - 1];
		}
		return newarr;
	}

	public static void main(String[] args) {
		// Initialize array
		int[] arr = new int[] { 3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0,0,0};
		int sum = 0; int  n=17,avg=0 ; 
		// Loop through the array to calculate sum of elements
		for (int i = 0; i < arr.length; i++) {
			sum = sum + arr[i];
		}
		for (int i = 0; i < arr.length; i++) {
			avg =sum /arr.length;
		}
		
		int pos=16;
		
		int pos1=17;
		 arr = insertX(n, arr, sum, pos);
		 arr = insertX(n, arr, avg, pos1);
		 
		System.out.println("Sum of all the elements of an array: " + sum);
		System.out.println("avg of all the elements of an array: " + avg);
		 // print the updated array
        System.out.println("\nArray with " + sum
                           + " inserted at position "
                           + pos + ":\n"
                           + Arrays.toString(arr));
        System.out.println("\nArray with " + avg
                + " inserted at position "
                + pos1 + ":\n"
                + Arrays.toString(arr));
        
	}
}
