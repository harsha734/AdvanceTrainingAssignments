package com;

import java.util.Arrays;
import java.util.Scanner;

class MergeSort {

	public static void sortedMerge(int a[], int b[], int res[], int n, int m) {

		Arrays.sort(a);
		Arrays.sort(b);

		int i = 0, j = 0, k = 0;
		while (i < n && j < m) {
			if (a[i] <= b[j]) {
				res[k] = a[i];
				i += 1;
				k += 1;
			} else {
				res[k] = b[j];
				j += 1;
				k += 1;
			}
		}

		while (i < n) {

			res[k] = a[i];
			i += 1;
			k += 1;
		}
		while (j < m) {
			res[k] = b[j];
			j += 1;
			k += 1;
		}
	}

	public static void main(String[] args) {

//        int a1[] = { 10,5,15 };
//        int b1[] = { 20, 3, 2};
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter length of array : ");
		int[] a1 = new int[sc.nextInt()];
		System.out.println("Enter array values : ");
		for (int i = 0; i < a1.length; i++) {
			a1[i] = sc.nextInt();

		}
		System.out.println("Enter length of array : ");
		int[] b1 = new int[sc.nextInt()];
		System.out.println("Enter array values : ");
		for (int i = 0; i < b1.length; i++) {
			b1[i] = sc.nextInt();

		}
		int n1 = a1.length;
		int m1 = b1.length;

		int res1[] = new int[n1 + m1];
		sortedMerge(a1, b1, res1, n1, m1);

		System.out.print("\n Merge Sorted  list :");
		for (int i = 0; i < n1 + m1; i++)
			System.out.print(" " + res1[i]);
		sc.close();

	}
}
