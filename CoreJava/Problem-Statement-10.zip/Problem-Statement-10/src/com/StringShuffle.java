package com;

import java.util.Scanner;

public class StringShuffle {
	public static boolean isShuffling(String first, String second, String third) {
		if (first.length() == 0 && second.length() == 0 && third.length() == 0) {
			return true;
		}
		if (third.length() == 0) {
			return false;
		}
		if (first.length() != 0 && third.charAt(0) == first.charAt(0)) {
			return isShuffling(first.substring(1), second, third.substring(1));
		}
		if (second.length() != 0 && third.charAt(0) == second.charAt(0)) {
			return isShuffling(first, second.substring(1), third.substring(1));
		}
		return false;
	}

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the First String :");
		String first=sc.next();
		System.out.println("Enter the Second String :");
		String second=sc.next();
		System.out.println("Enter the Third String :");
		String third=sc.next();
		if (isShuffling(first, second, third)) {
			System.out.print("true: given string is a valid shuffle of first and second string");
		} else {
			System.out.print("false: third string is not valid shuffle of first and second string");
		}
		sc.close();
	}
}
